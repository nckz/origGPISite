# Author: Nick Zwart
# Date: 2012oct28

import os
import gpi
import time
import numpy as np
import pymatbridge
from pymatbridge import Matlab

# use the packaged directory if no installed version is found.
if not os.path.isdir(pymatbridge.MATLAB_FOLDER):
    pymatbridge.MATLAB_FOLDER = gpi.RES_DIR+"/pymatbridge/matlab"


class ExternalNode(gpi.NodeAPI):
    """This node provides a simple input interface for editing Matlab code
    which will be used as the nodes compute() function.  The four InPorts
    provided are available in the Matlab environment as: 'in1', 'in2', 'in3',
    and 'in4' (similarly for the OutPorts).  This code is sent to the Matlab
    interpreter through the Python package Pymatbridge.  New widgets cannot be
    added to the widget interface.  The Matlab bridge and/or Matlab itself
    requires the use of the GPI_APPLOOP or GPI_THREAD for execution flow.

    This modules is just one example of how a matlab bridge could be made.
    There are other packages (mlabwrap, pymat, etc...) that have different
    mechanisms for communicating with matlab, which will affect the speed
    and ease of use.

    NOTE: 
        1) If the node is deleted before matlab is finished, matlab will
            continue to run in the background (use $pkill MATLAB).
        2) Multidimensional arrays are flattened when sending and receiving
            from Matlab, they must be reshaped at either end.
    """

    def execType(self):
        return gpi.GPI_THREAD

    def initUI(self):

        self.addWidget('TextBox', 'Status', val='Ready.')

        code = "% input variables from inports are: in1, in2, in3, in4\n" \
            + "% output variables for outports are: out1, out2, out3, out4\n" \
            + "\n" \
            + "% your code here...\n"

        # Widgets
        self.addWidget('TextEdit', 'Matlab Code', val=code)
        self.addWidget('StringBox', 'Matlab Path',
                       val="/Applications/MATLAB_R2012b.app/bin/matlab")
        self.addWidget('PushButton', 'Compute', button_title='Compute')

        # IO Ports
        self.addInPort('in1', obligation=gpi.OPTIONAL)
        self.addInPort('in2', obligation=gpi.OPTIONAL)
        self.addInPort('in3', obligation=gpi.OPTIONAL)
        self.addInPort('in4', obligation=gpi.OPTIONAL)
        self.addOutPort('out1')
        self.addOutPort('out2')
        self.addOutPort('out3')
        self.addOutPort('out4')

    def input2json(self, inp):
        if type(inp) is np.ndarray:
            # return np.str(inp) # puts in carriage returns
            return str(inp.tolist())
        elif inp is None:
            return '[]'
        else:
            return str(inp)

    def json2output(self, outp):

        # convert to python object
        try:
            exec('pyobj = %s' % outp)
        except:
            pyobj = None

        # assume its a list/array
        if type(pyobj) is list:
            if len(pyobj):
                return np.array(pyobj)
            else:
                return None

        # just return the direct conversion
        else:
            return pyobj

    def run_code(self, mlab, code):
        if str(mlab.run_code(code)['success']) == 'false':
            return False
        return True

    def compute(self):

        mpath = str(self.getVal('Matlab Path'))
        if not os.path.isfile(mpath):
            print "ERROR: Matlab path is not valid, skipping compute()..."
            self.setAttr('Status',
                val='ERROR: Matlab path is not valid, skipping compute()...')
            return 0

        # get matlab and the webserver started
        self.setAttr('Status', val='Starting Matlab from path.')
        mlab = Matlab(matlab=mpath, maxtime=10)
        if not mlab.start():
            print "ERROR: Matlab failed to start, skipping compute()..."
            self.setAttr('Status',
                val='ERROR: Matlab failed to start, skipping compute()...')
            return 0

        # make user input JSON compatible for transfer to matlab
        in1 = self.input2json(self.getData('in1'))
        in2 = self.input2json(self.getData('in2'))
        in3 = self.input2json(self.getData('in3'))
        in4 = self.input2json(self.getData('in4'))

        # run user input Matlab code
        try:
            # push user input to matlab
            self.setAttr('Status', val='Pushing in1.')
            if not self.run_code(mlab, 'in1=' + in1 + ';'):
                self.setAttr('Status', val='in1 data xmit failed.')

            self.setAttr('Status', val='Pushing in2.')
            if not self.run_code(mlab, 'in2=' + in2 + ';'):
                self.setAttr('Status', val='in2 data xmit failed.')

            self.setAttr('Status', val='Pushing in3.')
            if not self.run_code(mlab, 'in3=' + in3 + ';'):
                self.setAttr('Status', val='in3 data xmit failed.')

            self.setAttr('Status', val='Pushing in4.')
            if not self.run_code(mlab, 'in4=' + in4 + ';'):
                self.setAttr('Status', val='in4 data xmit failed.')

            # set output variables in matlab, init to None
            self.setAttr('Status', val='Pushing out1.')
            self.run_code(mlab, 'out1=[];')

            self.setAttr('Status', val='Pushing out2.')
            self.run_code(mlab, 'out2=[];')

            self.setAttr('Status', val='Pushing out3.')
            self.run_code(mlab, 'out3=[];')

            self.setAttr('Status', val='Pushing out4.')
            self.run_code(mlab, 'out4=[];')

            self.setAttr('Status', val='Running input user code.')
            code = str(self.getVal('Matlab Code'))
            if str(mlab.run_code(code)['success']) == 'false':
                self.setAttr('Status',
                                  val='ERROR: input Matlab code failed.')
            else:
                self.setAttr('Status',
                                  val='User code executed successfully.')

            # parse user output, keep in try: to ensure
            # the user chose JSON compatible types
            self.setAttr('Status', val='Retrieving out1.')
            out1 = self.json2output(mlab.get_variable('out1'))

            self.setAttr('Status', val='Retrieving out2.')
            out2 = self.json2output(mlab.get_variable('out2'))

            self.setAttr('Status', val='Retrieving out3.')
            out3 = self.json2output(mlab.get_variable('out3'))

            self.setAttr('Status', val='Retrieving out4.')
            out4 = self.json2output(mlab.get_variable('out4'))

        except:
            print "ERROR: User code did not execute!"

            # close matlab connection
            self.setAttr('Status', val='ERROR: Closing Matlab.')
            while not mlab.stop() or mlab.is_connected():
                print "Waiting for matlab to close..."
                time.sleep(1)

            self.setData('out1', None)
            self.setData('out2', None)
            self.setData('out3', None)
            self.setData('out4', None)

            txt = "ERROR: User code failed to execute:\n"
            cnt = 0
            for msg in sys.exc_info():
                txt += cnt*"\t" + str(msg) + "\n"
                cnt += 1
            self.setAttr('Status', val=txt)

        # close matlab connection
        self.setAttr('Status', val='Closing Matlab.')
        while not mlab.stop() or mlab.is_connected():
            print "Waiting for matlab to close..."
            time.sleep(1)

        self.setData('out1', out1)
        self.setData('out2', out2)
        self.setData('out3', out3)
        self.setData('out4', out4)

        self.setAttr('Status', val='Ready.')

        return(0)
