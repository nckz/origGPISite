# Author: David Smith
# Date: 2013nov22

import numpy as np
import gpi


class ExternalNode(gpi.NodeAPI):
    """Reduce the rank of a matrix by truncating the singular value decomposition
    """

    def initUI(self):

        # Widgets
        self.addWidget('Slider', 'Rank', val=1, min=1)
        self.addWidget('PushButton','Compute',toggle=True,val=True)

        # IO Ports
        self.addInPort('in', 'NPYarray', dtype=[np.float32, np.float64, np.complex64, np.complex128],
                       obligation=gpi.REQUIRED)
        self.addOutPort('out', 'NPYarray')


    def validate(self):
        data = self.getData('in')

        if len(data.shape) > 2:
            warn("SVD requires a matrix")
            return(1)

        if len(data.shape) == 1:  # degenerate case of a vector
            self.setAttr('Rank', max=1)
        else:
            self.setAttr('Rank', max=data.shape[1])

        return(0)

    def compute(self):

        import numpy as np
        from scipy.linalg import svd

        data = self.getData('in')

        if self.getVal('Compute'):
            u,s,v = svd(data, full_matrices=False)
        
            n_to_keep = self.getVal('Rank')
            s[n_to_keep:] = 0
            out = u.dot(np.diag(s).dot(v))
        
            self.setData('out', out)

        return(0)
