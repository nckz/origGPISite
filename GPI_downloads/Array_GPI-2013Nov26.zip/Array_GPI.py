# Author: David Smith
# Date: 2013Nov

import gpi
import numpy as np


class ExternalNode(gpi.NodeAPI):
    """
        blank array generator
    """
    def execType(self):
        return gpi.GPI_PROCESS

    def initUI(self):      

        # Widgets
        self.addWidget('TextBox', 'Info')
        self.addWidget('ExclusivePushButtons','Fill with',buttons=['zeros','ones','uniform','normal'],val=0)
        self.ndim = 8
        self.dim_base_name = 'Axis '
        self.addWidget('Slider', 'Dimensions', max=self.ndim, val=1, min=1)
        for i in range(self.ndim):
            self.addWidget('SpinBox', self.dim_base_name+str(i), min=1, val=1, max=gpi.GPI_INT_MAX)

        self.addWidget('PushButton','Compute',toggle=True)

        # IO Ports
        #self.addInPort('nskip', 'INT', obligation = gpi.OPTIONAL)

        self.addOutPort('out', 'NPYarray')

    def validate(self):
        return 0
            
    
    def compute(self):

        # visibility
        cdim = self.getVal('Dimensions')
        dims = []
        for i in xrange(self.ndim):
            if i < cdim:
                self.setAttr(self.dim_base_name+str(i), visible=True)
                dims.append(self.getVal(self.dim_base_name+str(i)))
            else:
                self.setAttr(self.dim_base_name+str(i), visible=False)



        import numpy as np
        #dims = (128,128)
        values = self.getVal('Fill with')
        info = 'Dimensions: ' + str(dims)
        self.setAttr('Info', val=info) 

        if self.getVal('Compute'):
            if values == 0:
                out = np.zeros(dims)
            elif values == 1:
                out = np.ones(dims)
            elif values == 2:
                out = np.random.random(dims)
            elif values == 3:
                out = np.random.normal(0, 1, dims)
            else:
                warn("somehow got an invalid value!")

            self.setData('out', out)

        return(0)
